clear all;
close all;

%% create graph

connectivity=10;
fileName= 'graph4.png';
type = 1;

img = imread(fileName);
[m,n] = size(img);
vc = length(find(img == 0));
fprintf('plotGraph :: Number of vertices : %d\n',vc);

vertices = zeros(vc,2);
index = 1;

for i = 1:m
    for j = 1:n
        if img(i,j)== 0
            vertices(index,:) = [i,j];%[(m-i),j];
            index = index + 1;
        end
    end
end

adjMatrix = createGraphFn(fileName, connectivity, type,vc);


%% construct degree Matrix
degMatrix = diag(sum(adjMatrix,2));

%% construct laplacian

lapMatrix = degMatrix - adjMatrix;

%%%%%%%%%%%%%%%%%%%%%%%%%%
% for comparision purpose
%  [ V, E ] = eig(lapMatrix); %V- EigenVectors; E-EigenValues
%  eVal = diag(E);
%  [sorteVal, idx] = sort(eVal);
%  eVal = eVal(idx);
%  V = V(:,idx);
%  x=V(:,1);
%  y=V(:,2);
%  z=V(:,3);
% 
% [idx,C] = kmeans(V(:,1:k),k);
% clust1 = find(idx == 1);
% clust2 = find(idx == 2);
%%%%%%%%%%%%%%%%%%%%%%
 
%% construct hear kernel

t = 2;
scaledLap = -lapMatrix .* t;
H = expm(scaledLap);

%% iterative heat diffusion

%intial heat distribution
hDistr = zeros(vc,1);

%randomly choose a heat scource
source = randi([1 vc],1,1); 

%set the distribution of source to 1
hDistr(source) = 1;

%iteratively perform heat diffusion
hiDistr = hDistr; 
%prev = hiDistr(source);
 for i= 1:15
       %prev = hiDistr(source);
       hiDistr = H*hiDistr;
       %[max(hiDistr) min(hiDistr)]
       %'*****************************'
       %plotHeatMap(vertices, hiDistr);
 end
    
 %% find clusters

k = 2;
[idx,C] = kmeans(hiDistr,k);
clust1 = find(idx == 1);
clust2 = find(idx == 2);

%% form the color matrix
colVertex=zeros(vc,3);
for i = 1:vc
    if idx(i) == 1
        colVertex(i,:)=[1,0,0];
      
    else
        colVertex(i,:)=[0,0,1];
    end
end

figure;
scatter(vertices(:,2),vertices(:,1),10,colVertex,'filled');
%plot(x,y,'r*', 'markers',5);
hold off

 
    